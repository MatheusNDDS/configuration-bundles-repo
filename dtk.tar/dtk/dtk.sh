#!/bin/bash
dtk_props=(
	--colors
	--stdout --cursor-off-label --beep
	--ok-label "✓"
	--yes-label "✓"
	--cancel-label "←"
	--no-label "x"
	--exit-label "x"
	--help-label "?"
	--extra-label "+"
)
dtk="dialog ${dtk_props[@]}"
