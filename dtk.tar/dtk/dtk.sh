#!/bin/bash
dtk_props=(
	--stdout --cursor-off-label --beep
	--keep-window
	--ok-label "✓"
	--yes-label "✓"
	--cancel-label "←"
	--no-label "x"
	--exit-label "x"
	--help-label "?"
	--extra-label "+"
)
dtk="dialog ${dtk_props[@]}"
